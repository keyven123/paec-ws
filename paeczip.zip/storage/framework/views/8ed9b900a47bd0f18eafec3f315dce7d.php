<?php
    $data = $data ?? [];
    $emailHeadline = $data['email_headline'] ?? 'Congratulations on another successful event!';
    $emailIntro = $data['email_intro'] ?? '';
    $emailFooterThanks = $data['email_footer_thanks'] ?? 'Thank you for partnering with <strong style="color:#FFD700;">Ticketoc</strong>!';

    $inquiry = $data['inquiry'] ?? [];
    $venue = $data['venue'] ?? [];
    $guest = $data['guest'] ?? [];
    $event = $data['event'] ?? [];

    $manageUrl = $data['manage_inquiry_url'] ?? '#';
    $privacy = $data['privacy_policy_link'] ?? '#';
    $terms = $data['tc_link'] ?? '#';
    $year = $data['current_year'] ?? date('Y');

    $logoPath = resource_path('views/emails/asset/ticketoc_thumbnail.png');
    if (is_readable($logoPath)) {
        $brandLogoSrc = $message->embed($logoPath);
    } elseif (is_readable(public_path('images/logo/ticketoc.png'))) {
        $brandLogoSrc = $message->embed(public_path('images/logo/ticketoc.png'));
    } else {
        $brandLogoSrc = asset('images/logo/ticketoc.png');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($data['email_page_title'] ?? 'Event Completed'); ?></title>
    <style type="text/css">
        body { font-family: 'Segoe UI', Arial, sans-serif; background:#0b0b0b; color:#f3f3f3; margin:0; padding:0; }
        .container { max-width:900px; margin:40px auto; background:#111; border-radius:10px; overflow:hidden; border:1px solid #1f1f1f; }
        .header { background:#000; padding:20px; text-align:center; border-bottom:1px solid #222; }
        .content { padding:24px; line-height:1.55; }
        h2 { color:#FFD700; margin:0 0 10px; }
        .intro { color:#d4d4d8; font-size:15px; margin:0 0 22px; }
        .status-badge { display:inline-block; background:#047857; color:#fff; border-radius:999px; padding:4px 12px; font-size:11px; font-weight:700; letter-spacing:.06em; text-transform:uppercase; }
        .card { background:#1a1a1a; border:1px solid #2a2a2a; border-radius:12px; margin-bottom:18px; overflow:hidden; }
        .success-card { padding:20px 22px; background:linear-gradient(135deg,#064e3b 0%,#022c22 100%); border:1px solid #10b981; text-align:center; }
        .success-text { color:#a7f3d0; font-size:15px; margin:0; }
        .detail-grid { width:100%; border-collapse:collapse; }
        .detail-grid td { padding:14px 18px; border-top:1px solid #2a2a2a; font-size:14px; vertical-align:top; }
        .detail-grid tr:first-child td { border-top:none; }
        .detail-label { width:38%; color:#FFD700; font-weight:600; }
        .detail-value { color:#f3f3f3; }
        .tip-box { margin-top:18px; padding:14px 16px; background:#022c22; border:1px solid #10b981; border-radius:8px; color:#a7f3d0; font-size:13px; }
        .footer { background:#000; color:#888; text-align:center; padding:16px; font-size:12px; border-top:1px solid #222; }
        .footer a { color:#FFD700; text-decoration:none; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <img src="<?php echo e($brandLogoSrc); ?>" alt="Ticketoc" width="96" height="96" style="max-width:96px;height:auto;display:block;margin:0 auto 8px;">
        <h2><?php echo e($emailHeadline); ?></h2>
    </div>

    <div class="content">
        <p class="intro"><?php echo e($emailIntro); ?></p>

        <p style="margin:0 0 18px;">
            <span class="status-badge"><?php echo e($inquiry['status'] ?? 'Completed'); ?></span>
            <?php if(!empty($inquiry['reference'])): ?>
                <span style="margin-left:10px;color:#a1a1aa;font-size:13px;">Ref #<?php echo e($inquiry['reference']); ?></span>
            <?php endif; ?>
        </p>

        <div class="card success-card">
            <p class="success-text">🎊 Another event successfully hosted through Ticketoc!</p>
        </div>

        <div class="card">
            <table role="presentation" class="detail-grid" width="100%" cellpadding="0" cellspacing="0">
                <tr>
                    <td class="detail-label">Venue</td>
                    <td class="detail-value"><?php echo e($venue['name'] ?? 'Venue listing'); ?></td>
                </tr>
                <tr>
                    <td class="detail-label">Customer</td>
                    <td class="detail-value"><?php echo e($guest['full_name'] ?? '—'); ?></td>
                </tr>
                <tr>
                    <td class="detail-label">Event date</td>
                    <td class="detail-value"><?php echo e($event['date'] ?? 'Not specified'); ?></td>
                </tr>
                <tr>
                    <td class="detail-label">Expected guests</td>
                    <td class="detail-value"><?php echo e(!empty($event['guest_count']) ? number_format($event['guest_count']) . ' guests' : 'Not specified'); ?></td>
                </tr>
                <?php if(!empty($event['completed_at'])): ?>
                    <tr>
                        <td class="detail-label">Marked complete</td>
                        <td class="detail-value"><?php echo e($event['completed_at']); ?></td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>

        <p style="margin:22px 0 18px;">
            <a href="<?php echo e($manageUrl); ?>" target="_blank" rel="noopener" style="display:inline-block;padding:12px 18px;border-radius:8px;text-decoration:none;font-weight:600;background:#059669;color:#ffffff !important;">
                View completed inquiry
            </a>
        </p>

        <div class="tip-box">
            <strong style="color:#a7f3d0;">Keep the momentum going</strong><br>
            A great event experience often leads to repeat bookings and referrals. Stay in touch with your customer and keep your venue calendar active on Ticketoc.
        </div>
    </div>

    <div class="footer">
        <p><?php echo $emailFooterThanks; ?><br>This is an automated notice that a venue booking was marked complete on Ticketoc.</p>
        <p>
            <a href="<?php echo e($terms); ?>">Terms & Conditions</a> |
            <a href="<?php echo e($privacy); ?>">Privacy Policy</a><br>
            &copy; <?php echo e($year); ?> Ticketoc. All Rights Reserved.
        </p>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Projects\paec\paec-ws\resources\views/emails/venue-event-completed-merchant-dark.blade.php ENDPATH**/ ?>